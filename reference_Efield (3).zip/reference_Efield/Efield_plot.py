#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 24 12:11:49 2026

@author: francesco.barantani
"""
# %%

import numpy as np
import matplotlib.pyplot as plt


data = np.genfromtxt('./E_field_20240716.dat', delimiter = ',').T


data[0] = data[0]-data[0][np.argmax(data[1])]

plt.figure(figsize = (8, 6))
plt.subplot(121)

plt.plot(data[0], data[1])

plt.xlabel('Time (ps)')
plt.ylabel(' Electric field (a.u.)')

ff = np.fft.fftshift(np.fft.fftfreq(len(data[0]), d= data[0][2]-data[0][1]))
spectrum = np.fft.fftshift(np.fft.fft(data[1]))


plt.subplot(122)
plt.plot(ff, np.abs(spectrum))
plt.xlabel('Frequency (THz)')
plt.ylabel('|Spectral amplitude| (a.u.)')

plt.xlim(0,2)

